//Write a Java program that takes five numbers as input to calculate and print the average of the numbers
package assignment2;

public class Average {

	public static void main(String[] args) {
		int a=1,b=2,c=3,d=4,e=5;
		int total=a+b+c+d+e;
		float avg=total/5;
		System.out.println("Average: "+avg);
	}

}
