//Write a Java program to print the sum, multiply, subtract, divide and remainder of two numbers
package assignment2;

public class Arithmetic {

	public static void main(String[] args) {
		int a=20, b=10;
		System.out.println("addition of a and b:"+(a+b));//30
		System.out.println("subtraction of a and b:"+(a-b));//10
		System.out.println("multiplication of a and b:"+(a*b));//200
		System.out.println("division of a and b:"+(a/b));//2
		System.out.println("remainder of a and b:"+(a%b));//0

	}

}
