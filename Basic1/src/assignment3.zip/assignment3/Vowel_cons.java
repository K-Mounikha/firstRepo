//Write a program to input any alphabet and check whether it is vowel or consonant?
package assignment3;

public class Vowel_cons {

	public static void main(String[] args) {
    char ch='a';
    if(ch=='a'||ch=='e'||ch=='i'||ch=='o'||ch=='u'||ch=='A'||ch=='E'||ch=='I'||ch=='O'||ch=='U'){
    	System.out.println("vowel");
    }
    else {
    	System.out.println("Consonent");
    }

	}

}
