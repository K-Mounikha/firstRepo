//Sum All Three Angles and Check Equal or Not in Java?
package assignment3;

public class Triangle_equal {

	public static void main(String[] args) {
	int s1=60,s2=60,s3=60;
    int total=s1+s2+s3;
    if(total==180) {
    	System.out.println("equal");
    }
    else {
    	System.out.println("not equal");
    }

	}

}
