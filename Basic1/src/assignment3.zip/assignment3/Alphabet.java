//Write a program to check whether a character is alphabet or not?
package assignment3;

public class Alphabet {

	public static void main(String[] args) {
	char ch='A';
	if(ch>='a'||ch>='A') {
		System.out.println("Alphabet");
	}
	else {
		System.out.println("Not an alpahebet");
	}
	}

}
