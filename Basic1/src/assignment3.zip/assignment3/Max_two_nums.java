//Write a program to find maximum between two numbers?
package assignment3;

public class Max_two_nums {

	public static void main(String[] args) {
		int num1=10,num2=20;
		if(num1>num2)
		{
			System.out.println("num1 is greater");
		}
		else {
			System.out.println("num2 is greater");
		}

	}

}
