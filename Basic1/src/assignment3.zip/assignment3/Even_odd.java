//Write a program to check whether a number is even or odd?
package assignment3;

public class Even_odd {

	public static void main(String[] args) {
		int num=10;
		if(num%2==0) {
			System.out.println("even");
		}
		else
		{
			System.out.println("odd");
		}

	}

}
