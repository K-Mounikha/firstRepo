//Write a program to check whether a number is negative, positive or zero?
package assignment3;

public class Positive_nega_zero {

	public static void main(String[] args) {
	int num=10;
	if(num>0) {
		System.out.println("positive");
	}
	else if(num<0) {
		System.out.println("negative");
	}
	else {
		System.out.println("zero");
	}
	}

}
