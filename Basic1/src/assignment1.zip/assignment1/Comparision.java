//Write a program to check if the two numbers 23 and 45 are equal.
package assignment1;

public class Comparision {

	public static void main(String[] args) {
		 int num1=23,num2=45;
         if (num1==num2){

    System.out.println("both are equal");

    }
        else{
        System.out.println("both are not equal");
        }

	}

}
