//Write a program to calculate the perimeter of a triangle having sides of length 2,3 and 5 units.

package assignment1;

public class Triangle_perimeter {

	public static void main(String[] args) {
		int s1=2,s2=3,s3=5,perimeter=0;
        perimeter=s1+s2+s3;
        System.out.println("perimeter of a triangle :"+perimeter);//10


	}

}
